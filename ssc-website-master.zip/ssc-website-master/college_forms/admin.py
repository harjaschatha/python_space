from django.contrib import admin
from college_forms.models import *


