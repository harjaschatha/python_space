from .base import *
try:
	from .local import *
except:
	live=True
else:
	live=False
if live:
	from .live import *
