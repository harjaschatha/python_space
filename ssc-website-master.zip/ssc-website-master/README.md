College Website
===========

This is a repo for St. Stephen's College website. Will be changing over to mysql before going live. This is in no way good code. Both the developers have since gotten better at writing code. Please don't judge...

Dependencies:
============
1. sqlite3
2. Python 2.7
3. Django-1.6.5
4. Pillow
